from typing import Optional

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

from delivery_interfaces.srv import ScanPackage, SetLiftState


class TaskManagerNode(Node):
    """High-level delivery task manager.

    For now this is a stub that wires up:
    - NavigateToPose action client (Nav2)
    - ScanPackage service client (vision scanner)
    - SetLiftState service client (manipulator)
    - /lift_cmd publisher and /lift_state subscriber
    - /task_state and /task_events publishers

    Later you'll implement a proper state machine in the states/ subpackage.
    """

    def __init__(self) -> None:
        super().__init__("task_manager_node")

        # Parameters
        self.declare_parameter("locations_file", "")
        self.declare_parameter("task_params_file", "")

        # Task state publishers
        self._task_state_pub = self.create_publisher(String, "/task_state", 10)
        self._task_events_pub = self.create_publisher(String, "/task_events", 10)

        # Manipulator interface
        self._lift_cmd_pub = self.create_publisher(String, "/lift_cmd", 10)
        self._lift_state_sub = self.create_subscription(
            String,
            "/lift_state",
            self.lift_state_callback,
            10,
        )

        # Service clients
        self._scan_client = self.create_client(ScanPackage, "scan_package")
        self._set_lift_state_client = self.create_client(SetLiftState, "set_lift_state")

        # Nav2 action client
        self._nav_client = ActionClient(self, NavigateToPose, "navigate_to_pose")

        # Internal state placeholders
        self._current_task_state: str = "IDLE"
        self._last_lift_state: Optional[str] = None

        # Periodic publisher of /task_state (for debugging)
        self._task_state_timer = self.create_timer(1.0, self.publish_task_state)

        self.get_logger().info("TaskManagerNode started (stub wiring only).")

    # ------------------------------------------------------------------ #
    # Callbacks / helpers
    # ------------------------------------------------------------------ #

    def lift_state_callback(self, msg: String) -> None:
        self._last_lift_state = msg.data
        self.get_logger().debug(f"lift_state: {self._last_lift_state}")

    def publish_task_state(self) -> None:
        msg = String()
        msg.data = self._current_task_state
        self._task_state_pub.publish(msg)

    # Example helper: send a Nav2 goal (not used yet)
    def send_nav_goal(self, x: float, y: float, yaw: float, frame_id: str = "map") -> None:
        if not self._nav_client.server_is_ready():
            self.get_logger().warn("NavigateToPose action server not ready.")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = PoseStamped()
        goal_msg.pose.header.frame_id = frame_id
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        # TODO: convert yaw -> quaternion (left as an exercise / later step)

        self.get_logger().info(
            f"Sending Nav2 goal to ({x:.2f}, {y:.2f}, yaw={yaw:.2f}) in frame {frame_id}."
        )
        self._nav_client.send_goal_async(goal_msg)

    # Example helper: call ScanPackage once
    async def call_scan_package(self) -> None:
        if not self._scan_client.service_is_ready():
            self.get_logger().warn("ScanPackage service not ready.")
            return

        req = ScanPackage.Request()
        req.trigger = True

        self.get_logger().info("Calling ScanPackage service...")
        future = self._scan_client.call_async(req)
        await future

        if future.result() is None:
            self.get_logger().warn("ScanPackage call failed or timed out.")
            return

        resp = future.result()
        self.get_logger().info(
            f"ScanPackage response: success={resp.success}, "
            f"dropoff_id={resp.dropoff_id}, message={resp.message}"
        )

    # Example helper: call SetLiftState once
    async def call_set_lift_state(self, target: str) -> None:
        if not self._set_lift_state_client.service_is_ready():
            self.get_logger().warn("SetLiftState service not ready.")
            return

        req = SetLiftState.Request()
        req.target_state = target

        self.get_logger().info(f"Calling SetLiftState target_state={target}...")
        future = self._set_lift_state_client.call_async(req)
        await future

        if future.result() is None:
            self.get_logger().warn("SetLiftState call failed or timed out.")
            return

        resp = future.result()
        self.get_logger().info(
            f"SetLiftState response: success={resp.success}, message={resp.message}"
        )


def main(args=None) -> None:
    rclpy.init(args=args)
    node = TaskManagerNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.get_logger().info("Shutting down TaskManagerNode...")
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
